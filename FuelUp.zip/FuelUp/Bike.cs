class Bike : Vehicle
{


    public Bike(string name, int passengers, string color, bool hasEngine)
    : base(name, passengers, color, hasEngine) { }


}